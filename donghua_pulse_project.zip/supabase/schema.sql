-- DONGHUA PULSE production schema for Supabase
-- Run in Supabase SQL Editor. Add only videos/links you have the right to distribute or embed.
create extension if not exists pgcrypto;

create table if not exists public.titles (
  id text primary key,
  title_ru text not null,
  title_en text not null,
  genre text not null default 'Fantasy',
  year integer,
  rating numeric(3,1) default 0,
  episode_count integer default 0,
  status text not null default 'Coming soon',
  poster_url text,
  description_ru text,
  description_en text,
  audio_options text[] not null default '{}',
  schedule_day text,
  official_url text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  title_id text not null references public.titles(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  rating integer check (rating between 1 and 5),
  created_at timestamptz not null default now(),
  unique(title_id, user_id)
);

create table if not exists public.watch_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  title_id text not null references public.titles(id) on delete cascade,
  season integer not null default 1,
  episode integer not null default 1,
  updated_at timestamptz not null default now(),
  primary key(user_id, title_id)
);

create table if not exists public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  title_id text not null references public.titles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, title_id)
);

alter table public.titles enable row level security;
alter table public.reviews enable row level security;
alter table public.watch_progress enable row level security;
alter table public.favorites enable row level security;

drop policy if exists "published titles are public" on public.titles;
create policy "published titles are public" on public.titles for select using (published = true);

drop policy if exists "reviews are readable" on public.reviews;
create policy "reviews are readable" on public.reviews for select using (true);
drop policy if exists "users create their own review" on public.reviews;
create policy "users create their own review" on public.reviews for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "users update their own review" on public.reviews;
create policy "users update their own review" on public.reviews for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "users delete their own review" on public.reviews;
create policy "users delete their own review" on public.reviews for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "own progress only" on public.watch_progress;
create policy "own progress only" on public.watch_progress for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "own favorites only" on public.favorites;
create policy "own favorites only" on public.favorites for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- IMPORTANT:
-- Keep the service_role key private. Never place it in the browser.
-- For production, only admins should insert/update titles; create an admin-only policy
-- or manage title rows through the Supabase dashboard.
-- Do not store payment status based on client-side flags. Verify payments server-side.
