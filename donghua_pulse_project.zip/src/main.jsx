import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import {
  Search, Play, ChevronRight, ChevronDown, Globe2, Heart, Clock3, CalendarDays,
  Star, Menu, X, Crown, Languages, Sparkles, CircleUserRound, Plus, Check,
  MessageCircle, Send, Film, LogIn, LogOut, ShieldCheck, ExternalLink
} from 'lucide-react';
import './styles.css';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = SUPABASE_URL && SUPABASE_KEY && !SUPABASE_URL.includes('YOUR_PROJECT')
  ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;

const catalog = [
  { id:'perfect-world', title:'Идеальный мир', en:'Perfect World', genre:'Фэнтези', year:2021, rating:9.2, episodes:208, status:'Выходит', color:'gold', image:'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=900&q=85', description:'Ши Хао растёт в мире, где кланы сражаются за древние тайны и невероятную силу.', audio:['Русские субтитры','中文 · 原声'], schedule:'Пятница' },
  { id:'renegade-immortal', title:'Бессмертный противостояния', en:'Renegade Immortal', genre:'Экшен', year:2023, rating:9.1, episodes:120, status:'Выходит', color:'violet', image:'https://images.unsplash.com/photo-1577083552431-6e5fd01aa342?auto=format&fit=crop&w=900&q=85', description:'Путь Ван Линя — история упорства, культивации и выбора собственной судьбы.', audio:['Русские субтитры','中文 · 原声'], schedule:'Понедельник' },
  { id:'swallowed-star', title:'Поглощённая звезда', en:'Swallowed Star', genre:'Научная фантастика', year:2020, rating:8.9, episodes:156, status:'Выходит', color:'blue', image:'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=900&q=85', description:'После глобальной катастрофы человечество борется за выживание в новом мире.', audio:['Русские субтитры','English subtitles','中文 · 原声'], schedule:'Вторник' },
  { id:'battle-through-heavens', title:'Расколотая битвой синева небес', en:'Battle Through the Heavens', genre:'Приключения', year:2018, rating:9.0, episodes:120, status:'Выходит', color:'orange', image:'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=900&q=85', description:'Сяо Янь возвращается на путь силы, чтобы восстановить честь и выполнить обещание.', audio:['Русские субтитры','中文 · 原声'], schedule:'Суббота' },
  { id:'soul-land', title:'Боевой континент', en:'Soul Land', genre:'Фэнтези', year:2018, rating:8.8, episodes:263, status:'Завершён', color:'pink', image:'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=900&q=85', description:'Тан Сань получает второй шанс и открывает мир духовных мастеров.', audio:['Русские субтитры','English subtitles','中文 · 原声'], schedule:'—' },
  { id:'demon-hunter', title:'Охотник на демонов', en:'The Demon Hunter', genre:'Экшен', year:2023, rating:8.7, episodes:52, status:'Выходит', color:'red', image:'https://images.unsplash.com/photo-1518709594023-6eab9bab7b23?auto=format&fit=crop&w=900&q=85', description:'Молодой воин защищает людей от демонических угроз и раскрывает тайны прошлого.', audio:['Русские субтитры','中文 · 原声'], schedule:'Пятница' },
];

const copy = {
 ru: {
  brandSub:'МИР КИТАЙСКОЙ АНИМАЦИИ', navHome:'Главная', navCatalog:'Каталог', navSchedule:'Расписание', navFavorites:'Избранное',
  search:'Поиск дунхуа...', heroTag:'ТВОЯ ВОЛНА ДУНХУА', heroTitle:'Истории, которые', heroTitle2:'выходят за пределы.', heroDesc:'Открой мир китайской анимации — от эпических культиваций до фантастических приключений.', explore:'Открыть каталог', latest:'Сейчас смотрят', popular:'Популярное', seeAll:'Весь каталог', trending:'В ТРЕНДЕ', all:'Все', action:'Экшен', fantasy:'Фэнтези', adventure:'Приключения', sciFi:'Научная фантастика',
  episodes:'серий', rating:'Рейтинг', continue:'Продолжить просмотр', continueDesc:'Вернись туда, где остановился.', schedule:'Расписание выхода', scheduleDesc:'Не пропусти новую серию.', favorites:'Моё избранное', favoritesDesc:'Сохранённые истории — в одном месте.', emptyFav:'Пока ничего нет в избранном.', addFav:'Добавить в избранное', removeFav:'Убрать из избранного', details:'Подробнее', watch:'Смотреть', episode:'Серия', season:'Сезон', audio:'Язык / субтитры', comments:'Отзывы сообщества', writeComment:'Поделись впечатлением...', send:'Отправить', signIn:'Войти', signOut:'Выйти', account:'Аккаунт', premium:'Pulse Premium', premiumDesc:'Меньше рекламы. Больше комфорта.', premiumCTA:'Посмотреть планы', free:'Бесплатно', premiumPlan:'Premium', month:'/ месяц', adLabel:'РЕКЛАМНОЕ МЕСТО', footer:'Создано для поклонников дунхуа.', legal:'Смотрите только официально доступные видео. Доступность зависит от региона и правообладателя.', notConnected:'Демо-режим: данные сохраняются в этом браузере.', loginTitle:'Войти в DONGHUA PULSE', email:'Электронная почта', password:'Пароль', createAccount:'Создать аккаунт', loginAction:'Войти', loginHint:'Подключите Supabase, чтобы включить аккаунты и синхронизацию.', videoUnavailable:'Видео ещё не добавлено', videoUnavailableDesc:'Мы показываем только официальные ссылки, добавленные администрацией.', officialSource:'Открыть официальный источник', sourceNote:'Ссылка на официальный видеосервис открывается отдельно.', noResults:'Ничего не найдено. Попробуйте другое название.', upcoming:'Скоро', weekdays:['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'], commentsNeedLogin:'Для публикации отзыва подключите аккаунт.', rate:'Оценить', selected:'Вы выбрали', language:'Язык', subtitle:'Субтитры'
 },
 en: {
  brandSub:'THE WORLD OF DONGHUA', navHome:'Home', navCatalog:'Catalog', navSchedule:'Schedule', navFavorites:'My List',
  search:'Search donghua...', heroTag:'YOUR DONGHUA WAVE', heroTitle:'Stories that go', heroTitle2:'beyond the horizon.', heroDesc:'Explore Chinese animation — from epic cultivation sagas to sci-fi adventures.', explore:'Explore catalog', latest:'Now watching', popular:'Popular', seeAll:'Full catalog', trending:'TRENDING', all:'All', action:'Action', fantasy:'Fantasy', adventure:'Adventure', sciFi:'Sci-fi',
  episodes:'episodes', rating:'Rating', continue:'Continue watching', continueDesc:'Pick up where you left off.', schedule:'Release schedule', scheduleDesc:'Never miss a new episode.', favorites:'My favorites', favoritesDesc:'Your saved stories, all in one place.', emptyFav:'Your list is empty for now.', addFav:'Add to favorites', removeFav:'Remove from favorites', details:'Details', watch:'Watch', episode:'Episode', season:'Season', audio:'Audio / subtitles', comments:'Community reviews', writeComment:'Share your thoughts...', send:'Post', signIn:'Sign in', signOut:'Sign out', account:'Account', premium:'Pulse Premium', premiumDesc:'Fewer ads. More comfort.', premiumCTA:'View plans', free:'Free', premiumPlan:'Premium', month:'/ month', adLabel:'AD SPACE', footer:'Made for donghua fans.', legal:'Watch only officially available videos. Availability depends on region and rights holders.', notConnected:'Demo mode: data is saved in this browser.', loginTitle:'Sign in to DONGHUA PULSE', email:'Email address', password:'Password', createAccount:'Create account', loginAction:'Sign in', loginHint:'Connect Supabase to enable accounts and sync.', videoUnavailable:'Video not added yet', videoUnavailableDesc:'Only official links added by the site administrator are shown.', officialSource:'Open official source', sourceNote:'The official video provider opens separately.', noResults:'No results. Try another title.', upcoming:'Coming up', weekdays:['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'], commentsNeedLogin:'Connect an account to post a review.', rate:'Rate', selected:'Selected', language:'Language', subtitle:'Subtitles'
 }
};

function App() {
 const [lang,setLang] = useState('ru');
 const t = copy[lang];
 const [activeNav,setActiveNav] = useState('home');
 const [query,setQuery] = useState('');
 const [genre,setGenre] = useState('all');
 const [favorites,setFavorites] = useState(()=>JSON.parse(localStorage.getItem('dp-favs')||'[]'));
 const [progress,setProgress] = useState(()=>JSON.parse(localStorage.getItem('dp-progress')||'{}'));
 const [selected,setSelected] = useState(null);
 const [episode,setEpisode] = useState(1);
 const [season,setSeason] = useState(1);
 const [audio,setAudio] = useState('');
 const [menuOpen,setMenuOpen] = useState(false);
 const [showLogin,setShowLogin] = useState(false);
 const [user,setUser] = useState(null);
 const [email,setEmail] = useState('');
 const [password,setPassword] = useState('');
 const [authBusy,setAuthBusy] = useState(false);
 const [notice,setNotice] = useState('');
 const [comments,setComments] = useState(()=>JSON.parse(localStorage.getItem('dp-comments')||'{}'));
 const [commentText,setCommentText] = useState('');
 const [rating,setRating] = useState(0);
 const [subscription,setSubscription] = useState(false);
 const [remoteTitles,setRemoteTitles] = useState(null);

 useEffect(()=>{ localStorage.setItem('dp-favs',JSON.stringify(favorites)); },[favorites]);
 useEffect(()=>{ localStorage.setItem('dp-progress',JSON.stringify(progress)); },[progress]);
 useEffect(()=>{ localStorage.setItem('dp-comments',JSON.stringify(comments)); },[comments]);
 useEffect(()=>{
   if(!supabase) return;
   supabase.auth.getSession().then(({data})=>setUser(data.session?.user||null));
   const {data:{subscription}} = supabase.auth.onAuthStateChange((_event,session)=>setUser(session?.user||null));
   return ()=>subscription.unsubscribe();
 },[]);
 useEffect(()=>{
   if(!supabase) return;
   supabase.from('titles').select('id,title_ru,title_en,genre,year,rating,episode_count,status,poster_url,description_ru,description_en,audio_options,schedule_day,official_url')
     .eq('published',true).then(({data,error})=>{ if(!error && data?.length) setRemoteTitles(data.map(x=>({...x,id:x.id,title:x.title_ru||x.title_en,en:x.title_en,episodes:x.episode_count,image:x.poster_url,description:lang==='ru'?x.description_ru:x.description_en, audio:x.audio_options||[],schedule:x.schedule_day,officialUrl:x.official_url}))); });
 },[lang]);
 const titles = remoteTitles || catalog;
 const normalized = (s='')=>s.toLowerCase();
 const visible = useMemo(()=>titles.filter(a=>{
   const title = lang==='ru'?(a.title||a.title_ru):(a.en||a.title_en||a.title);
   const q=normalized(query);
   const matches = normalized(title).includes(q)||normalized(a.en||a.title_en||'').includes(q);
   const g = genre==='all' || (genre==='action'&&['Экшен','Action'].includes(a.genre)) || (genre==='fantasy'&&['Фэнтези','Fantasy'].includes(a.genre)) || (genre==='adventure'&&['Приключения','Adventure'].includes(a.genre)) || (genre==='scifi'&&['Научная фантастика','Sci-fi'].includes(a.genre));
   return matches&&g&&(activeNav!=='favorites'||favorites.includes(a.id));
 }),[titles,query,genre,activeNav,favorites,lang]);
 const titleName = a => lang==='ru'?(a.title||a.title_ru):(a.en||a.title_en||a.title);
 const toggleFavorite = id=>setFavorites(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id]);
 const startWatching = a => { setSelected(a); setEpisode(progress[a.id]?.episode||1); setSeason(progress[a.id]?.season||1); setAudio(a.audio?.[0]||''); setRating(0); setCommentText(''); };
 const recordProgress = (a,ep,se) => setProgress(old=>({...old,[a.id]:{episode:ep,season:se,updatedAt:Date.now()}}));
 const signIn = async (e,create=false)=>{
   e.preventDefault();
   if(!supabase){setNotice(t.loginHint);return;}
   setAuthBusy(true);
   const result=create?await supabase.auth.signUp({email,password}):await supabase.auth.signInWithPassword({email,password});
   setAuthBusy(false);
   if(result.error) setNotice(result.error.message); else {setShowLogin(false);setNotice(create?'Check your email to confirm your account.':'');}
 };
 const postComment = async ()=>{
   if(!commentText.trim()) return;
   if(supabase && user && selected){
     const {error}=await supabase.from('reviews').upsert({title_id:selected.id,user_id:user.id,body:commentText.trim(),rating:rating||null},{onConflict:'title_id,user_id'});
     if(error){setNotice(error.message);return;}
   }
   const next={...comments,[selected.id]:[{id:Date.now(),name:user?.email?.split('@')[0]||'Guest',body:commentText.trim(),rating:rating||null},...(comments[selected.id]||[])]};
   setComments(next);setCommentText('');
 };
 const nav = (name)=>{setActiveNav(name);setSelected(null);setMenuOpen(false);window.scrollTo({top:0,behavior:'smooth'});};
 const navItems=[['home',t.navHome],['catalog',t.navCatalog],['schedule',t.navSchedule],['favorites',t.navFavorites]];
 const scheduleItems = titles.filter(x=>x.status!=='Завершён'&&x.status!=='Completed');
 const currentProgress = Object.entries(progress).map(([id,p])=>({title:titles.find(x=>x.id===id),...p})).filter(x=>x.title).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
 const checkout = ()=>{const url=import.meta.env.VITE_SUBSCRIPTION_CHECKOUT_URL;if(url)window.location.href=url;else setNotice('Subscription checkout is not configured yet. See README for secure billing setup.');};

 return <div className="app-shell">
  <header className="topbar">
   <button className="icon-btn mobile-menu" onClick={()=>setMenuOpen(!menuOpen)} aria-label="Menu">{menuOpen?<X/>:<Menu/>}</button>
   <button className="brand" onClick={()=>nav('home')}><span className="brand-mark"><Sparkles size={20}/></span><span className="brand-name">DONGHUA<span>PULSE</span><small>{t.brandSub}</small></span></button>
   <nav className={menuOpen?'nav-links open':'nav-links'}>{navItems.map(([id,label])=><button key={id} className={activeNav===id?'nav-link active':'nav-link'} onClick={()=>nav(id)}>{label}</button>)}</nav>
   <div className="top-actions">
    <label className="searchbox"><Search size={17}/><input value={query} onChange={e=>{setQuery(e.target.value);if(e.target.value)setActiveNav('catalog');}} placeholder={t.search}/><kbd>⌘ K</kbd></label>
    <button className="lang-btn" onClick={()=>setLang(lang==='ru'?'en':'ru')} title="Switch language"><Globe2 size={17}/>{lang.toUpperCase()}</button>
    {user?<button className="avatar-btn" onClick={()=>setNotice(user.email)} title={user.email}><CircleUserRound/></button>:<button className="login-btn" onClick={()=>setShowLogin(true)}><CircleUserRound size={17}/><span>{t.signIn}</span></button>}
   </div>
  </header>
  {notice&&<div className="toast" role="status">{notice}<button onClick={()=>setNotice('')}><X size={15}/></button></div>}
  {selected ? <main className="detail-page">
    <button className="back-link" onClick={()=>setSelected(null)}>← {t.navCatalog}</button>
    <div className="detail-hero">
      <div className="detail-poster" style={{backgroundImage:`linear-gradient(180deg,transparent,#0b0a12),url("${selected.image||selected.poster_url||''}")`}}><span className="poster-rating"><Star size={14} fill="currentColor"/>{selected.rating||'—'}</span></div>
      <div className="detail-copy"><span className="eyebrow">{selected.genre} · {selected.year}</span><h1>{titleName(selected)}</h1><p>{selected.description||selected.description_ru||'Описание скоро появится.'}</p><div className="meta-row"><span><Star size={16} fill="currentColor"/>{selected.rating||'—'} {t.rating}</span><span><Film size={16}/>{selected.episodes||selected.episode_count||'?'} {t.episodes}</span><span className="status-dot">{selected.status}</span></div>
       <div className="detail-actions"><button className="primary-btn" onClick={()=>{recordProgress(selected,episode,season);setNotice(t.videoUnavailable);}}><Play size={18} fill="currentColor"/>{t.watch}</button><button className={favorites.includes(selected.id)?'round-action liked':'round-action'} onClick={()=>toggleFavorite(selected.id)} aria-label={t.addFav}><Heart fill={favorites.includes(selected.id)?'currentColor':'none'}/></button></div>
      </div>
    </div>
    <div className="detail-columns">
     <section className="content-panel"><div className="section-head"><div><span className="eyebrow">EPISODES</span><h2>{t.season} {season}</h2></div><select value={season} onChange={e=>setSeason(Number(e.target.value))}><option value="1">{t.season} 1</option><option value="2">{t.season} 2</option><option value="3">{t.season} 3</option></select></div>
      <div className="episode-list">{Array.from({length:Math.min(12,Number(selected.episodes||selected.episode_count||12))},(_,i)=>i+1).map(ep=><button key={ep} className={episode===ep?'episode-row selected':'episode-row'} onClick={()=>{setEpisode(ep);recordProgress(selected,ep,season);setNotice(t.videoUnavailable);}}><span className="episode-play"><Play size={15} fill="currentColor"/></span><span><b>{t.episode} {ep}</b><small>{selected.status==='Завершён'?'Full episode':'Official source required'}</small></span><ChevronRight size={17}/></button>)}</div>
      <div className="video-placeholder"><div className="video-icon"><Play size={30} fill="currentColor"/></div><h3>{t.videoUnavailable}</h3><p>{t.videoUnavailableDesc}</p>{(selected.officialUrl||selected.official_url)&&<a className="primary-btn" href={selected.officialUrl||selected.official_url} target="_blank" rel="noreferrer">{t.officialSource}<ExternalLink size={16}/></a>}<small>{t.sourceNote}</small></div>
     </section>
     <aside className="content-panel side-panel"><h2>{t.audio}</h2><label className="field-label"><Languages size={16}/>{t.language}</label><select value={audio} onChange={e=>setAudio(e.target.value)}>{(selected.audio||selected.audio_options||['中文 · 原声']).map(x=><option key={x}>{x}</option>)}</select><p className="muted-note">Audio and subtitle options depend on the official provider.</p>
      <div className="review-heading"><h2>{t.comments}</h2><span>{(comments[selected.id]||[]).length}</span></div><div className="rating-picker"><span>{t.rate}</span>{[1,2,3,4,5].map(n=><button key={n} onClick={()=>setRating(n)} className={rating>=n?'star-on':'star-off'} aria-label={`${n} stars`}><Star size={18} fill={rating>=n?'currentColor':'none'}/></button>)}</div>
      <textarea value={commentText} onChange={e=>setCommentText(e.target.value)} placeholder={t.writeComment} rows="3"/><button className="primary-btn full-btn" onClick={postComment}><Send size={15}/>{t.send}</button>
      <div className="comments-list">{(comments[selected.id]||[]).map(c=><div className="comment" key={c.id}><div className="comment-avatar">{c.name.slice(0,1).toUpperCase()}</div><div><b>{c.name}</b>{c.rating&&<span className="comment-rating"> ★ {c.rating}/5</span>}<p>{c.body}</p></div></div>)}</div>
     </aside>
    </div>
   </main> : <main>
    {activeNav==='home'&&<section className="hero">
      <div className="hero-backdrop"></div><div className="hero-content"><span className="hero-pill"><span className="live-dot"></span>{t.heroTag}</span><h1>{t.heroTitle}<br/><em>{t.heroTitle2}</em></h1><p>{t.heroDesc}</p><div className="hero-buttons"><button className="primary-btn" onClick={()=>nav('catalog')}>{t.explore}<ChevronRight size={18}/></button><button className="secondary-btn" onClick={()=>startWatching(titles[0])}><Play size={17} fill="currentColor"/> {t.watch}</button></div><div className="hero-stats"><span><b>500+</b><small>Donghua titles</small></span><span><b>4K</b><small>Ready for big screens</small></span><span><b>2</b><small>Languages</small></span></div></div>
      <div className="hero-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="hero-character" style={{backgroundImage:`linear-gradient(180deg,transparent 55%,#0b0a12 100%),url("${titles[0]?.image}")`}}></div><div className="floating-tag"><Star size={15} fill="currentColor"/><span><b>{titles[0]?.rating}</b><small>Top rated</small></span></div><div className="vertical-label">DONGHUA · ANIME · CULTIVATION</div></div>
    </section>}
    {activeNav==='home'&&currentProgress.length>0&&<section className="section-block"><div className="section-head"><div><span className="eyebrow">PICK UP WHERE YOU LEFT OFF</span><h2>{t.continue}</h2><p>{t.continueDesc}</p></div></div><div className="continue-row">{currentProgress.slice(0,4).map(p=><button className="continue-card" key={p.title.id} onClick={()=>startWatching(p.title)}><img src={p.title.image||p.title.poster_url} alt=""/><span><b>{titleName(p.title)}</b><small>{t.season} {p.season} · {t.episode} {p.episode}</small><i><span style={{width:`${Math.min(100,p.episode/Math.max(1,p.title.episodes||12)*100)}%`}}/></i></span><Play size={18}/></button>)}</div></section>}
    {activeNav==='schedule' ? <section className="section-block page-section"><div className="section-head"><div><span className="eyebrow">DON'T MISS AN EPISODE</span><h2>{t.schedule}</h2><p>{t.scheduleDesc}</p></div><CalendarDays size={24}/></div><div className="schedule-list">{scheduleItems.map((a,i)=><button className="schedule-row" key={a.id} onClick={()=>startWatching(a)}><span className="schedule-day">{a.schedule||a.schedule_day||t.upcoming}</span><img src={a.image||a.poster_url} alt=""/><span className="schedule-title"><b>{titleName(a)}</b><small>{a.genre} · {a.status}</small></span><span className="schedule-episode">{t.episode} {Math.max(1,(a.episodes||a.episode_count||1)-1)} <ChevronRight size={16}/></span></button>)}</div></section> :
    <section className="section-block" id="catalog">
      <div className="section-head"><div><span className="eyebrow">{activeNav==='favorites'?'YOUR COLLECTION':'CURATED FOR YOU'}</span><h2>{activeNav==='favorites'?t.favorites:activeNav==='catalog'?t.navCatalog:t.popular}</h2><p>{activeNav==='favorites'?t.favoritesDesc:t.latest}</p></div><button className="text-link" onClick={()=>nav(activeNav==='catalog'?'home':'catalog')}>{activeNav==='catalog'?t.navHome:t.seeAll}<ChevronRight size={16}/></button></div>
      <div className="filter-row">{[['all',t.all],['action',t.action],['fantasy',t.fantasy],['adventure',t.adventure],['scifi',t.sciFi]].map(([id,label])=><button key={id} onClick={()=>setGenre(id)} className={genre===id?'filter-chip selected':'filter-chip'}>{label}</button>)}</div>
      {visible.length?<div className="poster-grid">{visible.map((a,i)=><article className="poster-card" key={a.id}><button className="poster-image" onClick={()=>startWatching(a)} style={{backgroundImage:`linear-gradient(180deg,transparent 45%,rgba(9,8,15,.95)),url("${a.image||a.poster_url}")`}}><span className="poster-badge">{i===0?t.trending:a.status}</span><span className="poster-rating"><Star size={13} fill="currentColor"/>{a.rating||'—'}</span><span className="poster-play"><Play size={20} fill="currentColor"/></span></button><div className="poster-info"><div><h3>{titleName(a)}</h3><p>{a.genre} <span>·</span> {a.year}</p></div><button className={favorites.includes(a.id)?'favorite-btn liked':'favorite-btn'} onClick={()=>toggleFavorite(a.id)} aria-label={t.addFav}><Heart size={17} fill={favorites.includes(a.id)?'currentColor':'none'}/></button></div><div className="poster-bottom"><span>{a.episodes||a.episode_count} {t.episodes}</span><button onClick={()=>startWatching(a)}>{t.details}<ChevronRight size={14}/></button></div></article>)}</div>:<div className="empty-state"><Heart size={30}/><h3>{activeNav==='favorites'?t.emptyFav:t.noResults}</h3><button className="secondary-btn" onClick={()=>{setQuery('');setGenre('all');nav('catalog')}}>{t.navCatalog}</button></div>}
    </section>}
    <section className="promo-section"><div className="promo-icon"><Crown size={26}/></div><div className="promo-copy"><span className="eyebrow">LEVEL UP YOUR EXPERIENCE</span><h2>{t.premium}</h2><p>{t.premiumDesc} Support the platform and enjoy a cleaner experience.</p></div><div className="promo-right"><div className="plan-price"><b>€4.99</b><small>{t.month}</small></div><button className="primary-btn" onClick={checkout}>{t.premiumCTA}<ChevronRight size={16}/></button></div></section>
    <section className="ad-slot"><span><Sparkles size={15}/>{t.adLabel}</span><b>Support official releases and creators.</b><small>Ad provider can be configured after launch and policy approval.</small></section>
   </main>}
  <footer className="footer"><button className="brand footer-brand" onClick={()=>nav('home')}><span className="brand-mark"><Sparkles size={18}/></span><span className="brand-name">DONGHUA<span>PULSE</span><small>{t.brandSub}</small></span></button><p>{t.footer}<br/><small>{t.legal}</small></p><div className="footer-links"><button onClick={()=>setNotice('Privacy policy: add a reviewed policy before public launch.')}>Privacy</button><button onClick={()=>setNotice('Terms: add terms and regional rights information before launch.')}>Terms</button><button onClick={()=>setNotice(t.notConnected)}><ShieldCheck size={15}/>{supabase?'Connected':'Demo mode'}</button></div></footer>
  {showLogin&&<div className="modal-backdrop" onClick={()=>setShowLogin(false)}><div className="login-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setShowLogin(false)}><X/></button><span className="brand-mark"><Sparkles size={22}/></span><h2>{t.loginTitle}</h2><p>{t.loginHint}</p><form onSubmit={e=>signIn(e,false)}><label>{t.email}<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></label><label>{t.password}<input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength="6" required/></label><button className="primary-btn full-btn" disabled={authBusy}>{authBusy?'...':t.loginAction}</button></form><button className="text-link" onClick={e=>{const form=e.currentTarget.closest('.login-modal').querySelector('form');signIn({preventDefault:()=>{}},true)}}>{t.createAccount}</button></div></div>}
 </div>;
}
createRoot(document.getElementById('root')).render(<App/>);
