# DONGHUA PULSE

Responsive Russian/English donghua catalog and streaming-site starter. Designed for iPad, phones, and desktop.

## What works in this starter

- Responsive catalog, search, genre filters, detail pages, season/episode picker.
- Language switch (Russian / English UI).
- Favorites and watch progress saved locally in the current browser.
- Local demo reviews and ratings.
- Release schedule section.
- Audio/subtitle option selector per title.
- Optional Supabase auth and database integration hooks.
- Subscription CTA placeholder and ad-placement placeholder.
- Official-source link field: the app does **not** pirate, scrape, or host copyrighted episodes.

## Important: this is a starter, not a launched streaming service

The included catalog uses illustrative metadata and remote decorative poster images. Episode playback is intentionally not faked: the detail page clearly explains when an official source has not been added. You must add only content you own, have licensed, or are authorized to embed. Check each provider's embed terms and territorial rights.

The subscription price is an example. Payment processing, ad network, legal terms, privacy policy, moderation and licensing must be configured before public launch.

## Run locally

1. Install Node.js LTS from https://nodejs.org/
2. Extract this folder.
3. Open a terminal in this folder.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local address printed by Vite (usually http://localhost:5173).

## Publish the frontend free of charge

Recommended: Netlify or Cloudflare Pages. You can also use Vercel.

### GitHub + Netlify (browser-friendly after initial setup)
1. Create a GitHub account and a new **private** repository.
2. Upload all project files, preserving folders.
3. In Netlify, choose **Add new site → Import an existing project** and connect GitHub.
4. Build command: `npm run build`
5. Publish directory: `dist`
6. Deploy. Netlify will give you a public URL.
7. If you later add Supabase, set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in the hosting provider's environment variables, then redeploy.

Cloudflare Pages uses the same build command and `dist` output folder.

## Enable accounts, reviews, favorites/progress sync

1. Create a project at https://supabase.com/
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Supabase Project Settings → API, copy the Project URL and `anon`/publishable key. Never expose the `service_role` key.
4. Copy `.env.example` to `.env.local`; fill in `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
5. Run `npm install` again if needed and restart `npm run dev`.
6. Configure Supabase Auth email settings and redirect URLs for localhost and your deployed domain.
7. Before production, finish wiring the app's local favorites/progress to the `favorites` and `watch_progress` tables. The schema and RLS policies are provided as a secure starting point, but this starter currently keeps favorites/progress in localStorage.

## Add a title and official video link

1. In Supabase Table Editor, open `titles`.
2. Add a row with a unique `id`, Russian/English title, genre, poster URL, description, audio options and `official_url`.
3. Set `published = true`.
4. Use an official provider URL only when its terms allow linking/embedding and you have the necessary rights.
5. Current starter opens `official_url` separately. To embed a provider player, implement a provider-specific player using the provider's official embed URL and documented player API. Do not use scraped links or unofficial mirrors.

Example `audio_options` array:
`{"Русские субтитры","中文 · 原声","English subtitles"}`

## Subscriptions and ads

### Subscription
- Choose a payment provider available for your business country (for example, Stripe where supported).
- Create products/prices in its dashboard.
- Implement a server-side checkout endpoint and webhook to verify payments.
- Set `VITE_SUBSCRIPTION_CHECKOUT_URL` to your secure checkout URL.
- Never grant Premium based on a browser-only flag or trust client-submitted payment claims.
- Implement entitlement checks server-side and review local tax/consumer rules.

### Ads
- Choose an ad network that accepts your site and audience.
- Add the network script only after approval and consent/privacy setup.
- Replace the ad placeholder with the approved ad component.
- Do not serve ads in ways that violate provider policies or children's privacy rules.

## Launch checklist

- [ ] Secure domain and HTTPS (usually provided by hosting).
- [ ] Add licensed/official video sources and verify regional availability.
- [ ] Confirm all poster/artwork usage rights.
- [ ] Create privacy policy, terms, cookie/consent notice and contact page.
- [ ] Add moderation/reporting tools for user comments.
- [ ] Add rate limiting, spam protection and abuse reporting.
- [ ] Configure email confirmation and production auth redirect URLs.
- [ ] Add server-side payment checkout + webhook verification.
- [ ] Add approved ad provider + consent management.
- [ ] Test on Safari iPadOS, iPhone Safari, Android and desktop browsers.
- [ ] Replace demo statistics and sample metadata with verified real data.

## Folder structure

```text
donghua-pulse/
├── index.html
├── package.json
├── .env.example
├── README.md
├── src/
│   ├── main.jsx
│   └── styles.css
└── supabase/
    └── schema.sql
```
